Some example notebooks and data set manipulations.

  stamps/ -- some examples of diginorm and partitioning on fake data.
  stamps k-mer distributions.ipynb -- ipython notebook to show distributions.

